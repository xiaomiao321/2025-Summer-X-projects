#include "iot/thing.h"
#include "board.h"
#include "audio_codec.h"

#include <driver/gpio.h>
#include <esp_log.h>

#define TAG "Motor"

namespace iot {

// 这里仅定义 Motor 的属性和方法，不包含具体的实现
class Motor : public Thing {
private:
    gpio_num_t gpio1_num_ = GPIO_NUM_43;
    gpio_num_t gpio2_num_ = GPIO_NUM_44;
    bool power_ = false;

    void InitializeGpio() {
        //配置第一个 GPIO 引脚
        gpio_config_t config1 = {
            .pin_bit_mask = (1ULL << gpio1_num_),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        ESP_ERROR_CHECK(gpio_config(&config1));
        gpio_set_level(gpio1_num_, 0);

        //配置第二个 GPIO 引脚
        gpio_config_t config2 = {
            .pin_bit_mask = (1ULL << gpio2_num_),
            .mode = GPIO_MODE_OUTPUT,
            .pull_up_en = GPIO_PULLUP_DISABLE,
            .pull_down_en = GPIO_PULLDOWN_DISABLE,
            .intr_type = GPIO_INTR_DISABLE,
        };
        ESP_ERROR_CHECK(gpio_config(&config2));
        gpio_set_level(gpio2_num_, 0);
    }

public:
Motor() : Thing("Motor", "一个测试用的电机"), power_(false) {
        InitializeGpio();

        // 定义设备的属性
        properties_.AddBooleanProperty("power", "电机是否转动", [this]() -> bool {
            return power_;
        });

        // 定义设备可以被远程执行的指令
        methods_.AddMethod("TurnOn", "打开电机", ParameterList(), [this](const ParameterList& parameters) {
            power_ = true;
            gpio_set_level(gpio1_num_, 1);
            gpio_set_level(gpio2_num_, 0);
        });

        methods_.AddMethod("TurnOff", "关闭电机", ParameterList(), [this](const ParameterList& parameters) {
            power_ = false;
            gpio_set_level(gpio1_num_, 0);
            gpio_set_level(gpio2_num_, 0);
        });

        methods_.AddMethod("motor_reversal", "电机反转", ParameterList(), [this](const ParameterList& parameters) {
            power_ = true;
            gpio_set_level(gpio1_num_, 0);
            gpio_set_level(gpio2_num_, 1);
        });
    }
};

} // namespace iot

DECLARE_THING(Motor);